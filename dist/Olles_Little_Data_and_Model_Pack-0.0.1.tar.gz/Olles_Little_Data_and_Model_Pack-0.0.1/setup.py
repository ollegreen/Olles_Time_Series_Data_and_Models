from setuptools import setup

setup(
    name='Olles_Little_Data_and_Model_Pack',
    version='0.0.1',
    description='R Passenger dataset but in list and Pandas format. Will later include time series models (will be added later).',
    py_modules='olles_little_data_and_model_pack',
    package_dir={'':'src'}
    )